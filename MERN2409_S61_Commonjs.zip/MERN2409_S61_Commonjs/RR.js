const TeamName = "Rajasthan Royals";
const Players = ["Sanju Samson", "Jos Buttler", "Yuzvendra Chahal"];
const Coach = "Kumar Sangakkara";
const description = () => {
  console.log(
    "Rajasthan Royals (RR) were the inaugural IPL champions, known for their focus on young talent."
  );
};

module.exports = { TeamName, Players, Coach, description };
