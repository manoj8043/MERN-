const TeamName = "Mumbai Indians";
const Players = ["Rohit Sharma", "Jasprit Bumrah", "Suryakumar Yadav"];
const Coach = "Mark Boucher";
const description = () => {
  console.log(
    "Mumbai Indians (MI) are the most successful IPL team with multiple championships, led by Rohit Sharma."
  );
};

module.exports = { TeamName, Players, Coach, description };
