const TeamName = "Chennai Super Kings";
const Players = ["MS Dhoni", "Ravindra Jadeja", "Ruturaj Gaikwad"];
const Coach = "Stephen Fleming";
const description = () => {
  console.log(
    "Chennai Super Kings (CSK) is one of the most successful teams in the IPL, known for their consistency and leadership under MS Dhoni."
  );
};

module.exports = { TeamName, Players, Coach, description };
