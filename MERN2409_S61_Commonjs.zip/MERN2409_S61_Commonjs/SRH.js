const TeamName = "Sunrisers Hyderabad";
const Players = ["Aiden Markram", "Bhuvneshwar Kumar", "Rahul Tripathi"];
const Coach = "Brian Lara";
const description = () => {
  console.log(
    "Sunrisers Hyderabad (SRH) is known for their strong bowling lineup and gritty performances."
  );
};

module.exports = { TeamName, Players, Coach, description };
