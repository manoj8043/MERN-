const TeamName = "Royal Challengers Bangalore";
const Players = ["Virat Kohli", "Glenn Maxwell", "Mohammed Siraj"];
const Coach = "Sanjay Bangar";
const description = () => {
  console.log(
    "Royal Challengers Bangalore (RCB) is known for its star-studded lineup and passionate fanbase."
  );
};

module.exports = { TeamName, Players, Coach, description };
