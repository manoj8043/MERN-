const TeamName = "Kolkata Knight Riders";
const Players = ["Shreyas Iyer", "Andre Russell", "Sunil Narine"];
const Coach = "Chandrakant Pandit";
const description = () => {
  console.log(
    "Kolkata Knight Riders (KKR) are two-time IPL champions, famous for their aggressive style and iconic fanbase."
  );
};

module.exports = { TeamName, Players, Coach, description };
