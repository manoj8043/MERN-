const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true,
    validate: {
      validator: function (v) {
        return /^[a-zA-Z][a-zA-Z\s'-]{1,}$/.test(v);
      },
      message: (props) => `${props.value} is not a valid email id`,
    },
  },
  lastName: {
    type: String,
    required: true,
    validate: {
      validator: function (v) {
        return /^[a-zA-Z][a-zA-Z\s'-]{1,}$/.test(v);
      },
      message: (props) => `${props.value} is not a valid email id`,
    },
  },
  age: {
    type: Number,
    min: [13, "Age should be greater than 13"],
    max: [20, "Age should be less than 20"],
    required: true,
  },
  email: {
    type: String,
    required: true,
    validate: {
      validator: function (v) {
        return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(v);
      },
      message: (props) => `${props.value} is not a valid email id`,
    },
  },
  batch: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  Gender: {
    type: String,
    required: true,
    lowercase: true,
    enum: ["male", "female", "others"],
  },
});

let Student = new mongoose.model("students", studentSchema, "2020Students");

//Create a new student
let insertStudentsIntoDB = async () => {
  try {
    let Manoj = new Student({
      firstName: "Manoj",
      lastName: "Kumar",
      age: 19,
      email: "manojkumar@gmail.com",
      batch: "2020",
      city: "Delhi",
      Gender: "male",
    });

    let Ramya = new Student({
      firstName: "Ramya",
      lastName: "Sri",
      age: 15,
      email: "Ramya@gmail.com",
      batch: "2020",
      city: "Delhi",
      Gender: "female",
    });

    let Priya = new Student({
      firstName: "Laasya",
      lastName: "Priya",
      age: 17,
      email: "Priya@gmail.com",
      batch: "2020",
      city: "Delhi",
      Gender: "female",
    });

    Student.insertMany([Priya, Ramya, Manoj]);
    console.log("Student inserted successfully");
  } catch (err) {
    console.log("Error in inserting student: ");
  }
};
//Connection to MongoDB
let connecttoMDB = async () => {
  try {
    await mongoose.connect(
      "mongodb+srv://Manoj:M123@cluster0.fufvh.mongodb.net/MERNDB?retryWrites=true&w=majority&appName=Cluster0"
    );
    insertStudentsIntoDB();
    console.log("Connected to MongoDB");
  } catch (err) {
    console.log("Error in connecting to MongoDB: ");
  }
};

connecttoMDB();
