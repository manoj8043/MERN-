import "./App.css";
import { useEffect, useState } from "react";

function App() {
  // let [stars, setStars] = useState([]);
  let [deals, setDeals] = useState([]);

  // let onButtonclick = async () => {
  //   let reqOptions = {
  //     method: "GET",
  //   };
  //   let JSONData = await fetch(
  //     "http://localhost:4567/pushpastarcast",
  //     reqOptions
  //   );
  //   let JSOdata = await JSONData.json();
  //   setStars(JSOdata);
  // };

  useEffect(() => {
    async function fetchData() {
      let reqOptions = {
        method: "GET",
      };
      let JSONData = await fetch("http://localhost:4567/DealsPage", reqOptions);
      let JSOdata = await JSONData.json();
      setDeals(JSOdata);
    }
    fetchData();
  }, []);

  return (
    <div>
      {/* <button
        onClick={() => {
          onButtonclick();
        }}
      >
        Submit
      </button>
      {stars.map((ele, i) => {
        return <div key={i}>{<h3>{ele}</h3>}</div>;
      })} */}
      <h1>
        ⚡⚡⚡<u>Lightning Deals</u>⚡⚡⚡
      </h1>
      <div className="ProdectsTab">
        {deals.map((ele, i) => {
          return (
            <div className="Product" key={i}>
              <h3>{ele.title}</h3>
              <img src={ele.image} alt="" />
              <h3>
                ${ele.price} <del> ${(ele.price * 1.3).toFixed(2)}</del>
              </h3>
              <p>
                {ele.rating.rate}⭐ ({ele.rating.count})
              </p>
              <p>{ele.description}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default App;
