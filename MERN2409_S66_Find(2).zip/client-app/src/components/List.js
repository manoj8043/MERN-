import React from "react";
import { useState } from "react";
// import { useEffect } from "react";

function List() {
  let [students, setStudents] = useState([]);

  let getStudentsListFromServer = async () => {
    let reqOption = {
      method: "GET",
    };
    let JSONData = await fetch("http://localhost:32232/StudentList", reqOption);
    let JSOData = await JSONData.json();
    setStudents(JSOData);
  };

  // useEffect(() => {
  //   getStudentsListFromServer();
  // }, []);
  return (
    <div>
      <form>
        <button
          type="button"
          onClick={() => {
            getStudentsListFromServer();
          }}
        >
          Get Employees
        </button>
      </form>
      <hr></hr>
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            <th>id</th>
            <th>Profile</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Batch</th>
            <th>City</th>
          </tr>
        </thead>
        <tbody>
          {students.map((ele, i) => {
            return (
              <tr key={i}>
                <td>{i + 1}</td>
                <td>{ele.id}</td>
                <td>
                  <img src={ele.Profile} alt=""></img>
                </td>
                <td>{ele.firstName}</td>
                <td>{ele.lastName}</td>
                <td>{ele.email}</td>
                <td>{ele.age}</td>
                <td>{ele.Gender}</td>
                <td>{ele.batch}</td>
                <td>{ele.City}</td>
              </tr>
            );
          })}
        </tbody>
        <tfoot></tfoot>
      </table>
    </div>
  );
}

export default List;
